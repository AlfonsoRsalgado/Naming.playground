//number of GB on Iphone
let iphonesc = 8
//nimber of Megabytes in Gigabytes
let mb = 1000
//number of storage used in GB
let storageused = 3
//number of storage one minute video uses in MB
let numberOfstroagevideo = 150
//total number of MB iphone has
let tmb = iphonesc * mb
// Mb iphone used
let numberOfmbu = storageused * mb
//number of space left in Mega bytes
let numberOfspaceleft = tmb - numberOfmbu

let videos = numberOfspaceleft / numberOfstroagevideo 
//:[Previous](@previous)  |  page 12 of 14  |  [Next: Exercise: Fixing Your Morning](@next)
